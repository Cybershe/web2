#import tensorflow as tf
import split_folders
split_folders.ratio(r'C:\Users\DELL\Documents\Downloads\keras-yolo3-master\keras-yolo3-master\model_data\data',"save_folders",seed=3430,ratio=(.8,.2))
